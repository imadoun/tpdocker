import time

print "\t\tLancement du programme mathematique dit \"De Syracuse\" \n"

etape = 0

saisie = int(input("Entrez le nombre : "))
time_depart = time.clock()
     
while 1:
        etape = etape +1
        if saisie == 0:
                print "\nImpossible de lancer le calcul avec un nombre nul !\n"
                break
        if saisie == 1:
                print "\t\t\tC\'est termine on trouve le nombre 1 !\n\n"
                break
        if (saisie % 2 == 0):
                saisie = saisie / 2
        else :
                saisie = saisie * 3 + 1

time_fin = time.clock()

time_calcul = time_fin - time_depart
print "Temps : " , time_calcul , " secondes !"

print "Le programme est passe par", etape , "etapes ! \n\n"

raw_input("")

